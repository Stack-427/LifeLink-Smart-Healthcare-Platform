import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type Role = 'donor' | 'recipient' | 'hospital' | 'admin';

export type DonationType =
  | 'Blood'
  | 'Organ'
  | 'Tissue'
  | 'Plasma'
  | 'Platelet'
  | 'Bone Marrow'
  | 'Eye Donation';

export const DONATION_TYPES: DonationType[] = [
  'Blood',
  'Organ',
  'Tissue',
  'Plasma',
  'Platelet',
  'Bone Marrow',
  'Eye Donation',
];

export const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as const;

export const URGENCY_LEVELS = ['low', 'medium', 'high', 'critical'] as const;
export const REQUEST_STATUSES = ['pending', 'accepted', 'completed', 'cancelled'] as const;

export interface Profile {
  id: string;
  role: Role;
  full_name: string;
  phone: string;
  location: string;
  latitude: number | null;
  longitude: number | null;
  avatar_url: string;
  created_at: string;
}

export interface Hospital {
  id: string;
  profile_id: string;
  name: string;
  type: 'hospital' | 'blood_bank';
  address: string;
  city: string;
  latitude: number | null;
  longitude: number | null;
  phone: string;
  created_at: string;
}

export interface Donor {
  id: string;
  user_id: string;
  blood_group: string | null;
  donation_types: string[];
  is_available: boolean;
  last_donation_date: string | null;
  medical_notes: string;
  created_at: string;
}

export interface Request {
  id: string;
  requester_id: string;
  hospital_id: string | null;
  donation_type: string;
  blood_group: string | null;
  urgency: string;
  status: string;
  patient_name: string;
  description: string;
  location: string;
  latitude: number | null;
  longitude: number | null;
  accepted_by: string | null;
  accepted_at: string | null;
  completed_at: string | null;
  created_at: string;
}

export interface Donation {
  id: string;
  donor_id: string;
  request_id: string | null;
  hospital_id: string | null;
  donation_type: string;
  blood_group: string | null;
  quantity: string;
  notes: string;
  donated_at: string;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  message: string;
  link: string | null;
  is_read: boolean;
  created_at: string;
}
