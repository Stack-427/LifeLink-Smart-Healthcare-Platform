import { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import AuthPage from './components/auth/AuthPage';
import AppLayout, { View } from './components/layout/AppLayout';
import Dashboard from './components/dashboard/Dashboard';
import DonorSearch from './components/search/DonorSearch';
import EmergencyRequests from './components/requests/EmergencyRequests';
import DonorDirectory from './components/donors/DonorDirectory';
import Analytics from './components/analytics/Analytics';
import ProfilePage from './components/profile/ProfilePage';

function AppContent() {
  const { user, profile, loading } = useAuth();
  const [view, setView] = useState<View>('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
          <p className="text-sm text-slate-500">Loading LifeLink...</p>
        </div>
      </div>
    );
  }

  if (!user || !profile) {
    return <AuthPage />;
  }

  // Role-based view filtering: redirect if user tries to access a view not allowed for their role
  const roleViewMap: Record<string, View[]> = {
    donor: ['dashboard', 'requests', 'profile'],
    recipient: ['dashboard', 'search', 'requests', 'profile'],
    hospital: ['dashboard', 'search', 'requests', 'donors', 'analytics', 'profile'],
    admin: ['dashboard', 'search', 'requests', 'donors', 'analytics', 'profile'],
  };
  const allowedViews = roleViewMap[profile.role] ?? ['dashboard', 'profile'];
  const activeView = allowedViews.includes(view) ? view : 'dashboard';

  return (
    <AppLayout currentView={activeView} onNavigate={setView}>
      {activeView === 'dashboard' && <Dashboard onNavigate={(v) => setView(v as View)} />}
      {activeView === 'search' && <DonorSearch />}
      {activeView === 'requests' && <EmergencyRequests />}
      {activeView === 'donors' && <DonorDirectory />}
      {activeView === 'analytics' && <Analytics />}
      {activeView === 'profile' && <ProfilePage />}
    </AppLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
