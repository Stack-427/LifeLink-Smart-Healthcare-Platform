import { useEffect, useState } from 'react';
import { TrendingUp, Droplet, Users, AlertCircle, Activity } from 'lucide-react';
import { supabase, Donation, Request } from '../../lib/supabase';
import { BarChart, DonutChart, LineChart } from '../ui/Charts';

export default function Analytics() {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [requests, setRequests] = useState<Request[]>([]);
  const [donorCount, setDonorCount] = useState(0);
  const [userCount, setUserCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [{ data: allDonations }, { data: allReqs }, { count: dCount }, { count: uCount }] = await Promise.all([
        supabase.from('donations').select('*'),
        supabase.from('requests').select('*'),
        supabase.from('donors').select('id', { count: 'exact', head: true }),
        supabase.from('profiles').select('id', { count: 'exact', head: true }),
      ]);
      setDonations((allDonations as Donation[]) ?? []);
      setRequests((allReqs as Request[]) ?? []);
      setDonorCount(dCount ?? 0);
      setUserCount(uCount ?? 0);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <span className="w-8 h-8 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
      </div>
    );
  }

  // Donation type distribution
  const typeData = donations.reduce<Record<string, number>>((acc, d) => {
    acc[d.donation_type] = (acc[d.donation_type] ?? 0) + 1;
    return acc;
  }, {});
  const donutData = Object.entries(typeData).map(([label, value], i) => ({
    label,
    value,
    color: ['#16bd80', '#0ea5e9', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'][i % 7],
  }));

  // Request status breakdown
  const statusData = [
    { label: 'Pending', value: requests.filter((r) => r.status === 'pending').length, color: '#f59e0b' },
    { label: 'Accepted', value: requests.filter((r) => r.status === 'accepted').length, color: '#0ea5e9' },
    { label: 'Completed', value: requests.filter((r) => r.status === 'completed').length, color: '#16bd80' },
    { label: 'Cancelled', value: requests.filter((r) => r.status === 'cancelled').length, color: '#94a3b8' },
  ];

  // Urgency distribution
  const urgencyData = [
    { label: 'Low', value: requests.filter((r) => r.urgency === 'low').length, color: '#94a3b8' },
    { label: 'Medium', value: requests.filter((r) => r.urgency === 'medium').length, color: '#0ea5e9' },
    { label: 'High', value: requests.filter((r) => r.urgency === 'high').length, color: '#f59e0b' },
    { label: 'Critical', value: requests.filter((r) => r.urgency === 'critical').length, color: '#ef4444' },
  ];

  // Monthly trend (last 6 months)
  const now = new Date();
  const months: { label: string; value: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0, 23, 59, 59);
    const count = donations.filter((don) => {
      const dt = new Date(don.donated_at);
      return dt >= d && dt <= monthEnd;
    }).length;
    months.push({ label: d.toLocaleString('default', { month: 'short' }), value: count });
  }

  const completionRate = requests.length > 0
    ? Math.round((requests.filter((r) => r.status === 'completed').length / requests.length) * 100)
    : 0;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-xl font-bold text-slate-900">Platform Analytics</h2>
        <p className="text-sm text-slate-500 mt-0.5">Overview of donations, requests, and platform activity</p>
      </div>

      {/* Top stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-5">
          <div className="w-11 h-11 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center mb-3">
            <Droplet className="w-5.5 h-5.5" />
          </div>
          <p className="text-2xl font-bold text-slate-900">{donations.length}</p>
          <p className="text-sm text-slate-500">Total Donations</p>
        </div>
        <div className="card p-5">
          <div className="w-11 h-11 rounded-xl bg-accent-50 text-accent-600 flex items-center justify-center mb-3">
            <Users className="w-5.5 h-5.5" />
          </div>
          <p className="text-2xl font-bold text-slate-900">{donorCount}</p>
          <p className="text-sm text-slate-500">Active Donors</p>
        </div>
        <div className="card p-5">
          <div className="w-11 h-11 rounded-xl bg-warning-50 text-warning-600 flex items-center justify-center mb-3">
            <AlertCircle className="w-5.5 h-5.5" />
          </div>
          <p className="text-2xl font-bold text-slate-900">{requests.filter((r) => r.status === 'pending' || r.status === 'accepted').length}</p>
          <p className="text-sm text-slate-500">Active Requests</p>
        </div>
        <div className="card p-5">
          <div className="w-11 h-11 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center mb-3">
            <TrendingUp className="w-5.5 h-5.5" />
          </div>
          <p className="text-2xl font-bold text-slate-900">{completionRate}%</p>
          <p className="text-sm text-slate-500">Completion Rate</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Donations by Type</h3>
          {donutData.length > 0 ? (
            <DonutChart data={donutData} />
          ) : (
            <p className="text-sm text-slate-400 py-12 text-center">No donation data yet</p>
          )}
        </div>

        <div className="card p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Request Status</h3>
          <BarChart data={statusData} />
        </div>

        <div className="card p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Donation Trend (6 months)</h3>
          <LineChart data={months} />
        </div>

        <div className="card p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Urgency Distribution</h3>
          <BarChart data={urgencyData} />
        </div>
      </div>

      {/* Summary */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-4">
          <Activity className="w-5 h-5 text-primary-600" />
          <h3 className="font-semibold text-slate-900">Platform Summary</h3>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
          <div>
            <p className="text-slate-500">Total Users</p>
            <p className="text-lg font-bold text-slate-900">{userCount}</p>
          </div>
          <div>
            <p className="text-slate-500">Total Requests</p>
            <p className="text-lg font-bold text-slate-900">{requests.length}</p>
          </div>
          <div>
            <p className="text-slate-500">Completed</p>
            <p className="text-lg font-bold text-primary-600">{requests.filter((r) => r.status === 'completed').length}</p>
          </div>
          <div>
            <p className="text-slate-500">Critical Requests</p>
            <p className="text-lg font-bold text-danger-600">{requests.filter((r) => r.urgency === 'critical').length}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
