import { ReactNode } from 'react';
import { Heart, LayoutDashboard, Search, AlertCircle, Users, BarChart3, LogOut, Droplet } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import NotificationBell from './NotificationBell';

export type View = 'dashboard' | 'search' | 'requests' | 'donors' | 'analytics' | 'profile';

interface NavItem {
  id: View;
  label: string;
  icon: typeof LayoutDashboard;
  roles: string[];
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['donor', 'recipient', 'hospital', 'admin'] },
  { id: 'search', label: 'Find Donors', icon: Search, roles: ['recipient', 'hospital', 'admin'] },
  { id: 'requests', label: 'Emergency Requests', icon: AlertCircle, roles: ['donor', 'recipient', 'hospital', 'admin'] },
  { id: 'donors', label: 'Donor Directory', icon: Droplet, roles: ['hospital', 'admin'] },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, roles: ['hospital', 'admin'] },
  { id: 'profile', label: 'My Profile', icon: Users, roles: ['donor', 'recipient', 'hospital', 'admin'] },
];

interface Props {
  children: ReactNode;
  currentView: View;
  onNavigate: (v: View) => void;
}

export default function AppLayout({ children, currentView, onNavigate }: Props) {
  const { profile, signOut } = useAuth();
  const items = NAV_ITEMS.filter((i) => i.roles.includes(profile?.role ?? 'donor'));

  const roleLabel: Record<string, string> = {
    donor: 'Donor',
    recipient: 'Recipient',
    hospital: 'Hospital / Blood Bank',
    admin: 'Administrator',
  };

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col fixed h-full z-30 hidden lg:flex">
        <div className="px-6 py-5 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-primary-600 rounded-xl flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" fill="white" />
            </div>
            <span className="text-lg font-bold text-slate-900">LifeLink</span>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {items.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                currentView === item.id
                  ? 'bg-primary-50 text-primary-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <item.icon className="w-4.5 h-4.5" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="px-3 py-4 border-t border-slate-100">
          <div className="flex items-center gap-3 px-3 py-2 mb-1">
            <div className="w-9 h-9 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-semibold text-sm">
              {profile?.full_name?.charAt(0).toUpperCase() ?? 'U'}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-slate-900 truncate">{profile?.full_name}</p>
              <p className="text-xs text-slate-500">{roleLabel[profile?.role ?? 'donor']}</p>
            </div>
          </div>
          <button
            onClick={signOut}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-600 hover:bg-danger-50 hover:text-danger-600 transition-colors"
          >
            <LogOut className="w-4.5 h-4.5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <div className="lg:hidden fixed top-0 left-0 right-0 bg-white border-b border-slate-200 z-30 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
            <Heart className="w-4.5 h-4.5 text-white" fill="white" />
          </div>
          <span className="font-bold text-slate-900">LifeLink</span>
        </div>
        <NotificationBell />
      </div>

      {/* Mobile bottom nav */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-30 flex justify-around px-2 py-1.5">
        {items.slice(0, 5).map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-lg ${
              currentView === item.id ? 'text-primary-600' : 'text-slate-400'
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span className="text-[9px] font-medium">{item.label.split(' ')[0]}</span>
          </button>
        ))}
      </div>

      {/* Main content */}
      <div className="flex-1 lg:ml-64 min-w-0">
        <header className="hidden lg:flex items-center justify-between px-8 py-4 bg-white border-b border-slate-200 sticky top-0 z-20">
          <h1 className="text-lg font-semibold text-slate-900 capitalize">
            {items.find((i) => i.id === currentView)?.label ?? 'Dashboard'}
          </h1>
          <NotificationBell />
        </header>
        <main className="p-4 lg:p-8 pb-20 lg:pb-8 max-w-7xl mx-auto">{children}</main>
      </div>
    </div>
  );
}
