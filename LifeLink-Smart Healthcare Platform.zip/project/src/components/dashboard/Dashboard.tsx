import { useEffect, useState } from 'react';
import { Droplet, Heart, AlertCircle, Activity, TrendingUp, Users, Building2, Clock } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { supabase, Donation, Request } from '../../lib/supabase';
import { BarChart, DonutChart } from '../ui/Charts';
import { StatusBadge, UrgencyBadge } from '../ui/StatusBadge';

function StatCard({ icon: Icon, label, value, color }: { icon: typeof Droplet; label: string; value: string | number; color: string }) {
  return (
    <div className="card p-5 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-3">
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="w-5.5 h-5.5" />
        </div>
      </div>
      <p className="text-2xl font-bold text-slate-900">{value}</p>
      <p className="text-sm text-slate-500 mt-0.5">{label}</p>
    </div>
  );
}

export default function Dashboard({ onNavigate }: { onNavigate: (v: string) => void }) {
  const { profile, user } = useAuth();
  const [donations, setDonations] = useState<Donation[]>([]);
  const [requests, setRequests] = useState<Request[]>([]);
  const [stats, setStats] = useState({ totalDonations: 0, activeDonors: 0, activeRequests: 0, completedRequests: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      if (!user) return;
      const role = profile?.role;

      if (role === 'donor') {
        const [{ data: myDonations }, { data: openReqs }] = await Promise.all([
          supabase.from('donations').select('*').eq('donor_id', user.id).order('donated_at', { ascending: false }),
          supabase.from('requests').select('*').eq('status', 'pending').order('created_at', { ascending: false }).limit(5),
        ]);
        setDonations((myDonations as Donation[]) ?? []);
        setRequests((openReqs as Request[]) ?? []);
        setStats({ totalDonations: myDonations?.length ?? 0, activeDonors: 0, activeRequests: openReqs?.length ?? 0, completedRequests: 0 });
      } else if (role === 'recipient') {
        const { data: myReqs } = await supabase.from('requests').select('*').eq('requester_id', user.id).order('created_at', { ascending: false });
        setRequests((myReqs as Request[]) ?? []);
        setStats({
          totalDonations: 0,
          activeDonors: 0,
          activeRequests: myReqs?.filter((r) => r.status === 'pending' || r.status === 'accepted').length ?? 0,
          completedRequests: myReqs?.filter((r) => r.status === 'completed').length ?? 0,
        });
      } else if (role === 'hospital' || role === 'admin') {
        const [{ data: allReqs }, { data: allDonations }, { count: donorCount }] = await Promise.all([
          supabase.from('requests').select('*').order('created_at', { ascending: false }),
          supabase.from('donations').select('*'),
          supabase.from('donors').select('id', { count: 'exact', head: true }),
        ]);
        setRequests((allReqs as Request[]) ?? []);
        setDonations((allDonations as Donation[]) ?? []);
        setStats({
          totalDonations: allDonations?.length ?? 0,
          activeDonors: donorCount ?? 0,
          activeRequests: allReqs?.filter((r) => r.status === 'pending' || r.status === 'accepted').length ?? 0,
          completedRequests: allReqs?.filter((r) => r.status === 'completed').length ?? 0,
        });
      }
      setLoading(false);
    }
    load();
  }, [user, profile]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <span className="w-8 h-8 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
      </div>
    );
  }

  const role = profile?.role ?? 'donor';

  // Charts data
  const donationTypeData = donations.reduce<Record<string, number>>((acc, d) => {
    acc[d.donation_type] = (acc[d.donation_type] ?? 0) + 1;
    return acc;
  }, {});
  const donutData = Object.entries(donationTypeData).map(([label, value], i) => ({
    label,
    value,
    color: ['#16bd80', '#0ea5e9', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'][i % 7],
  }));

  const statusData = [
    { label: 'Pending', value: requests.filter((r) => r.status === 'pending').length, color: '#f59e0b' },
    { label: 'Accepted', value: requests.filter((r) => r.status === 'accepted').length, color: '#0ea5e9' },
    { label: 'Completed', value: requests.filter((r) => r.status === 'completed').length, color: '#16bd80' },
    { label: 'Cancelled', value: requests.filter((r) => r.status === 'cancelled').length, color: '#94a3b8' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome banner */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-2xl p-6 lg:p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/3 blur-2xl" />
        <div className="relative z-10">
          <h2 className="text-2xl font-bold mb-1">Welcome back, {profile?.full_name?.split(' ')[0]}!</h2>
          <p className="text-primary-100">
            {role === 'donor' && 'Thank you for being a lifesaver. Here is your donation activity.'}
            {role === 'recipient' && 'Track your donation requests and find donors.'}
            {role === 'hospital' && 'Manage donors, requests, and hospital operations.'}
            {role === 'admin' && 'Platform overview and analytics at a glance.'}
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {role === 'donor' && (
          <>
            <StatCard icon={Droplet} label="My Donations" value={stats.totalDonations} color="bg-primary-50 text-primary-600" />
            <StatCard icon={AlertCircle} label="Open Requests" value={stats.activeRequests} color="bg-warning-50 text-warning-600" />
            <StatCard icon={Heart} label="Lives Impacted" value={stats.totalDonations} color="bg-danger-50 text-danger-600" />
            <StatCard icon={Activity} label="Availability" value="Active" color="bg-accent-50 text-accent-600" />
          </>
        )}
        {role === 'recipient' && (
          <>
            <StatCard icon={AlertCircle} label="Active Requests" value={stats.activeRequests} color="bg-warning-50 text-warning-600" />
            <StatCard icon={Activity} label="Completed" value={stats.completedRequests} color="bg-primary-50 text-primary-600" />
            <StatCard icon={Droplet} label="Total Requests" value={requests.length} color="bg-accent-50 text-accent-600" />
            <StatCard icon={TrendingUp} label="Success Rate" value={requests.length > 0 ? `${Math.round((stats.completedRequests / requests.length) * 100)}%` : '—'} color="bg-primary-50 text-primary-600" />
          </>
        )}
        {(role === 'hospital' || role === 'admin') && (
          <>
            <StatCard icon={Droplet} label="Total Donations" value={stats.totalDonations} color="bg-primary-50 text-primary-600" />
            <StatCard icon={Users} label="Active Donors" value={stats.activeDonors} color="bg-accent-50 text-accent-600" />
            <StatCard icon={AlertCircle} label="Active Requests" value={stats.activeRequests} color="bg-warning-50 text-warning-600" />
            <StatCard icon={Activity} label="Completed" value={stats.completedRequests} color="bg-primary-50 text-primary-600" />
          </>
        )}
      </div>

      {/* Charts row */}
      {(role === 'hospital' || role === 'admin') && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card p-6">
            <h3 className="font-semibold text-slate-900 mb-4">Donations by Type</h3>
            {donutData.length > 0 ? (
              <DonutChart data={donutData} />
            ) : (
              <p className="text-sm text-slate-400 py-12 text-center">No donation data yet</p>
            )}
          </div>
          <div className="card p-6">
            <h3 className="font-semibold text-slate-900 mb-4">Request Status Breakdown</h3>
            <BarChart data={statusData} />
          </div>
        </div>
      )}

      {/* Recent activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-900">
              {role === 'donor' ? 'Open Emergency Requests' : 'Recent Requests'}
            </h3>
            <button onClick={() => onNavigate('requests')} className="text-sm text-primary-600 font-medium hover:text-primary-700">
              View all
            </button>
          </div>
          {requests.length === 0 ? (
            <p className="text-sm text-slate-400 py-8 text-center">No requests yet</p>
          ) : (
            <div className="space-y-3">
              {requests.slice(0, 5).map((r) => (
                <div key={r.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors">
                  <div className="w-10 h-10 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0">
                    <Droplet className="w-4.5 h-4.5 text-primary-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-slate-900 truncate">{r.donation_type}</p>
                      {r.blood_group && <span className="badge bg-danger-50 text-danger-700">{r.blood_group}</span>}
                    </div>
                    <p className="text-xs text-slate-500 truncate">{r.patient_name || r.description || 'No details'}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <StatusBadge status={r.status} />
                    <UrgencyBadge urgency={r.urgency} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {role === 'donor' && (
          <div className="card p-6">
            <h3 className="font-semibold text-slate-900 mb-4">My Donation History</h3>
            {donations.length === 0 ? (
              <div className="py-8 text-center">
                <Droplet className="w-10 h-10 text-slate-200 mx-auto mb-2" />
                <p className="text-sm text-slate-400">No donations recorded yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {donations.slice(0, 5).map((d) => (
                  <div key={d.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                    <div className="w-10 h-10 rounded-lg bg-primary-100 flex items-center justify-center shrink-0">
                      <Heart className="w-4.5 h-4.5 text-primary-600" fill="currentColor" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900">{d.donation_type}</p>
                      <p className="text-xs text-slate-500">{new Date(d.donated_at).toLocaleDateString()}</p>
                    </div>
                    {d.blood_group && <span className="badge bg-danger-50 text-danger-700">{d.blood_group}</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {(role === 'hospital' || role === 'admin') && (
          <div className="card p-6">
            <h3 className="font-semibold text-slate-900 mb-4">Recent Donations</h3>
            {donations.length === 0 ? (
              <p className="text-sm text-slate-400 py-8 text-center">No donations recorded yet</p>
            ) : (
              <div className="space-y-3">
                {donations.slice(0, 5).map((d) => (
                  <div key={d.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                    <div className="w-10 h-10 rounded-lg bg-primary-100 flex items-center justify-center shrink-0">
                      <Heart className="w-4.5 h-4.5 text-primary-600" fill="currentColor" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900">{d.donation_type}</p>
                      <p className="text-xs text-slate-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(d.donated_at).toLocaleDateString()}
                      </p>
                    </div>
                    {d.blood_group && <span className="badge bg-danger-50 text-danger-700">{d.blood_group}</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {role === 'recipient' && (
          <div className="card p-6">
            <h3 className="font-semibold text-slate-900 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button onClick={() => onNavigate('requests')} className="w-full flex items-center gap-3 p-4 rounded-xl bg-primary-50 hover:bg-primary-100 transition-colors text-left">
                <AlertCircle className="w-5 h-5 text-primary-600" />
                <div>
                  <p className="text-sm font-semibold text-primary-900">Create Emergency Request</p>
                  <p className="text-xs text-primary-700">Post an urgent donation need</p>
                </div>
              </button>
              <button onClick={() => onNavigate('search')} className="w-full flex items-center gap-3 p-4 rounded-xl bg-accent-50 hover:bg-accent-100 transition-colors text-left">
                <Building2 className="w-5 h-5 text-accent-600" />
                <div>
                  <p className="text-sm font-semibold text-accent-900">Find Donors</p>
                  <p className="text-xs text-accent-700">Search nearby donors by blood group</p>
                </div>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
