import { useEffect, useState } from 'react';
import { Droplet, MapPin, Users } from 'lucide-react';
import { supabase, Donor, Profile } from '../../lib/supabase';

interface DonorWithProfile extends Donor {
  profiles?: Profile;
}

export default function DonorDirectory() {
  const [donors, setDonors] = useState<DonorWithProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from('donors')
        .select('*, profiles!donors_user_id_fkey(*)')
        .order('created_at', { ascending: false });
      setDonors((data as DonorWithProfile[]) ?? []);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <span className="w-8 h-8 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
      </div>
    );
  }

  const availableCount = donors.filter((d) => d.is_available).length;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Donor Directory</h2>
          <p className="text-sm text-slate-500 mt-0.5">All registered donors on the platform</p>
        </div>
        <div className="flex gap-3">
          <div className="card px-4 py-2.5">
            <p className="text-xs text-slate-500">Total Donors</p>
            <p className="text-lg font-bold text-slate-900">{donors.length}</p>
          </div>
          <div className="card px-4 py-2.5">
            <p className="text-xs text-slate-500">Available</p>
            <p className="text-lg font-bold text-primary-600">{availableCount}</p>
          </div>
        </div>
      </div>

      {donors.length === 0 ? (
        <div className="card p-12 text-center">
          <Users className="w-12 h-12 text-slate-200 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No donors registered yet</p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-5 py-3">Donor</th>
                  <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-5 py-3">Blood Group</th>
                  <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-5 py-3">Donation Types</th>
                  <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-5 py-3">Location</th>
                  <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-5 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {donors.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-primary-100 text-primary-700 flex items-center justify-center font-semibold text-sm shrink-0">
                          {d.profiles?.full_name?.charAt(0).toUpperCase() ?? 'D'}
                        </div>
                        <span className="text-sm font-medium text-slate-900">{d.profiles?.full_name ?? 'Unknown'}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      {d.blood_group ? (
                        <span className="badge bg-danger-50 text-danger-700 font-bold">
                          <Droplet className="w-3 h-3" fill="currentColor" />
                          {d.blood_group}
                        </span>
                      ) : (
                        <span className="text-sm text-slate-400">—</span>
                      )}
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex flex-wrap gap-1">
                        {d.donation_types?.slice(0, 3).map((t) => (
                          <span key={t} className="badge bg-slate-100 text-slate-600">{t}</span>
                        ))}
                        {d.donation_types?.length > 3 && (
                          <span className="text-xs text-slate-400">+{d.donation_types.length - 3}</span>
                        )}
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="text-sm text-slate-600 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {d.profiles?.location || '—'}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      {d.is_available ? (
                        <span className="badge bg-primary-100 text-primary-700">Available</span>
                      ) : (
                        <span className="badge bg-slate-100 text-slate-500">Unavailable</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
