import { useEffect, useState, useMemo } from 'react';
import { Search, MapPin, Droplet, Filter, X } from 'lucide-react';
import { supabase, Donor, Profile, BLOOD_GROUPS, DONATION_TYPES } from '../../lib/supabase';

interface DonorWithProfile extends Donor {
  profiles?: Profile;
}

export default function DonorSearch() {
  const [donors, setDonors] = useState<DonorWithProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [bloodGroup, setBloodGroup] = useState('');
  const [donationType, setDonationType] = useState('');
  const [location, setLocation] = useState('');
  const [availableOnly, setAvailableOnly] = useState(false);

  useEffect(() => {
    async function load() {
      setLoading(true);
      let query = supabase
        .from('donors')
        .select('*, profiles!donors_user_id_fkey(*)');

      if (bloodGroup) query = query.eq('blood_group', bloodGroup);
      if (donationType) query = query.contains('donation_types', [donationType]);
      if (availableOnly) query = query.eq('is_available', true);

      const { data } = await query.order('created_at', { ascending: false });
      setDonors((data as DonorWithProfile[]) ?? []);
      setLoading(false);
    }
    load();
  }, [bloodGroup, donationType, availableOnly]);

  const filtered = useMemo(() => {
    if (!location.trim()) return donors;
    return donors.filter((d) =>
      d.profiles?.location?.toLowerCase().includes(location.toLowerCase())
    );
  }, [donors, location]);

  const clearFilters = () => {
    setBloodGroup('');
    setDonationType('');
    setLocation('');
    setAvailableOnly(false);
  };

  const hasFilters = bloodGroup || donationType || location || availableOnly;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Search bar */}
      <div className="card p-5">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="flex-1 relative">
            <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by location or city..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="input pl-11"
            />
          </div>
          <select value={bloodGroup} onChange={(e) => setBloodGroup(e.target.value)} className="input lg:w-40">
            <option value="">All Blood Groups</option>
            {BLOOD_GROUPS.map((bg) => (
              <option key={bg} value={bg}>{bg}</option>
            ))}
          </select>
          <select value={donationType} onChange={(e) => setDonationType(e.target.value)} className="input lg:w-44">
            <option value="">All Types</option>
            {DONATION_TYPES.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
          <button
            onClick={() => setAvailableOnly((v) => !v)}
            className={`btn ${availableOnly ? 'bg-primary-600 text-white' : 'bg-white border border-slate-300 text-slate-700'}`}
          >
            <Filter className="w-4 h-4" />
            Available
          </button>
          {hasFilters && (
            <button onClick={clearFilters} className="btn-secondary">
              <X className="w-4 h-4" />
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Results count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-500">
          <span className="font-semibold text-slate-900">{filtered.length}</span> donor{filtered.length !== 1 ? 's' : ''} found
        </p>
      </div>

      {/* Donor grid */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <span className="w-8 h-8 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="card p-12 text-center">
          <Search className="w-12 h-12 text-slate-200 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No donors match your filters</p>
          <p className="text-sm text-slate-400 mt-1">Try adjusting your search criteria</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((d) => (
            <div key={d.id} className="card p-5 hover:shadow-md transition-shadow group">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-lg shrink-0">
                  {d.profiles?.full_name?.charAt(0).toUpperCase() ?? 'D'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-slate-900 truncate">{d.profiles?.full_name ?? 'Unknown'}</p>
                  <p className="text-xs text-slate-500 flex items-center gap-1 truncate">
                    <MapPin className="w-3 h-3 shrink-0" />
                    {d.profiles?.location || 'Location not set'}
                  </p>
                </div>
                {d.is_available ? (
                  <span className="badge bg-primary-100 text-primary-700">Available</span>
                ) : (
                  <span className="badge bg-slate-100 text-slate-500">Unavailable</span>
                )}
              </div>

              <div className="flex items-center gap-2 mb-3">
                {d.blood_group && (
                  <span className="badge bg-danger-50 text-danger-700 font-bold">
                    <Droplet className="w-3 h-3" fill="currentColor" />
                    {d.blood_group}
                  </span>
                )}
              </div>

              <div className="flex flex-wrap gap-1.5">
                {d.donation_types?.map((t) => (
                  <span key={t} className="badge bg-slate-100 text-slate-600">{t}</span>
                ))}
              </div>

              {d.last_donation_date && (
                <p className="text-xs text-slate-400 mt-3">
                  Last donation: {new Date(d.last_donation_date).toLocaleDateString()}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
