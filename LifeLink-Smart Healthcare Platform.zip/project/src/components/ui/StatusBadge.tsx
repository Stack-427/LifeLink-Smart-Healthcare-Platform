export function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    pending: 'bg-warning-100 text-warning-700',
    accepted: 'bg-accent-100 text-accent-700',
    completed: 'bg-primary-100 text-primary-700',
    cancelled: 'bg-slate-100 text-slate-600',
  };
  return (
    <span className={`badge ${styles[status] ?? 'bg-slate-100 text-slate-600'}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

export function UrgencyBadge({ urgency }: { urgency: string }) {
  const styles: Record<string, string> = {
    low: 'bg-slate-100 text-slate-600',
    medium: 'bg-accent-100 text-accent-700',
    high: 'bg-warning-100 text-warning-700',
    critical: 'bg-danger-100 text-danger-700',
  };
  return (
    <span className={`badge ${styles[urgency] ?? 'bg-slate-100 text-slate-600'}`}>
      {urgency.charAt(0).toUpperCase() + urgency.slice(1)}
    </span>
  );
}
