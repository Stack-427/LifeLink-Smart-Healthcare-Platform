import { useState } from 'react';
import { Heart, Droplet, Activity, Building2, Shield, Mail, Lock, User, ArrowRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const ROLES = [
  { value: 'donor', label: 'Donor', icon: Droplet, desc: 'Save lives by donating' },
  { value: 'recipient', label: 'Recipient', icon: Heart, desc: 'Find donors & request' },
  { value: 'hospital', label: 'Hospital / Blood Bank', icon: Building2, desc: 'Manage requests & donors' },
] as const;

export default function AuthPage() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<string>('donor');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    if (mode === 'login') {
      const { error } = await signIn(email, password);
      if (error) setError(error);
    } else {
      const { error } = await signUp(email, password, role, fullName);
      if (error) setError(error);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left panel — branding */}
      <div className="lg:w-1/2 bg-gradient-to-br from-primary-700 via-primary-600 to-primary-800 text-white p-8 lg:p-16 flex flex-col justify-between relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-accent-400 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-11 h-11 bg-white/15 backdrop-blur rounded-2xl flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" fill="white" />
            </div>
            <span className="text-2xl font-bold tracking-tight">LifeLink</span>
          </div>
        </div>
        <div className="relative z-10 max-w-md">
          <h1 className="text-3xl lg:text-5xl font-bold leading-tight mb-4">
            Every donation is a second chance at life.
          </h1>
          <p className="text-primary-100 text-lg leading-relaxed">
            Connect donors, recipients, and hospitals in real time. Track emergency
            requests, find nearby donors, and save lives together.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-4">
            {[
              { icon: Droplet, label: '7 Donation Types' },
              { icon: Activity, label: 'Real-time Tracking' },
              { icon: Shield, label: 'Secure & Verified' },
            ].map((f) => (
              <div key={f.label} className="bg-white/10 backdrop-blur rounded-xl p-3 text-center">
                <f.icon className="w-5 h-5 mx-auto mb-1.5 text-primary-100" />
                <p className="text-xs font-medium text-primary-50">{f.label}</p>
              </div>
            ))}
          </div>
        </div>
        <p className="relative z-10 text-primary-200 text-sm">
          © 2026 LifeLink. Connecting lives, one donation at a time.
        </p>
      </div>

      {/* Right panel — form */}
      <div className="lg:w-1/2 flex items-center justify-center p-8 lg:p-16 bg-slate-50">
        <div className="w-full max-w-md animate-slide-up">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-900">
              {mode === 'login' ? 'Welcome back' : 'Create your account'}
            </h2>
            <p className="text-slate-500 mt-1">
              {mode === 'login'
                ? 'Sign in to access your dashboard'
                : 'Join LifeLink and start saving lives'}
            </p>
          </div>

          {error && (
            <div className="mb-5 p-3.5 rounded-xl bg-danger-50 border border-danger-100 text-danger-700 text-sm animate-fade-in">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <>
                <div>
                  <label className="label">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="John Doe"
                      className="input pl-11"
                    />
                  </div>
                </div>
                <div>
                  <label className="label">I am a...</label>
                  <div className="grid grid-cols-3 gap-2.5">
                    {ROLES.map((r) => (
                      <button
                        key={r.value}
                        type="button"
                        onClick={() => setRole(r.value)}
                        className={`p-3 rounded-xl border-2 text-center transition-all ${
                          role === r.value
                            ? 'border-primary-500 bg-primary-50'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        }`}
                      >
                        <r.icon
                          className={`w-5 h-5 mx-auto mb-1.5 ${
                            role === r.value ? 'text-primary-600' : 'text-slate-400'
                          }`}
                        />
                        <p
                          className={`text-xs font-semibold ${
                            role === r.value ? 'text-primary-700' : 'text-slate-600'
                          }`}
                        >
                          {r.label}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="label">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="input pl-11"
                />
              </div>
            </div>

            <div>
              <label className="label">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="input pl-11"
                />
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? (
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  {mode === 'login' ? 'Sign In' : 'Create Account'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <p className="text-center text-sm text-slate-500 mt-6">
            {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
            <button
              onClick={() => {
                setMode(mode === 'login' ? 'signup' : 'login');
                setError(null);
              }}
              className="text-primary-600 font-semibold hover:text-primary-700"
            >
              {mode === 'login' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
