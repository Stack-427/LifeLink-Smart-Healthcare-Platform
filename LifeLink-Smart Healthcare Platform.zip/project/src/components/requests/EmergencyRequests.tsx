import { useEffect, useState } from 'react';
import { AlertCircle, Plus, X, Droplet, Clock, MapPin, CheckCircle, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { supabase, Request, BLOOD_GROUPS, DONATION_TYPES, URGENCY_LEVELS } from '../../lib/supabase';
import { StatusBadge, UrgencyBadge } from '../ui/StatusBadge';

export default function EmergencyRequests() {
  const { user, profile } = useAuth();
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  // Form state
  const [donationType, setDonationType] = useState('Blood');
  const [bloodGroup, setBloodGroup] = useState('');
  const [urgency, setUrgency] = useState('medium');
  const [patientName, setPatientName] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const bloodTypes = ['Blood', 'Plasma', 'Platelet'];

  useEffect(() => {
    fetchRequests();
    const channel = supabase
      .channel('requests-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'requests' }, () => {
        fetchRequests();
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchRequests = async () => {
    const { data } = await supabase
      .from('requests')
      .select('*')
      .order('created_at', { ascending: false });
    setRequests((data as Request[]) ?? []);
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!user) return;
    setSubmitting(true);

    const needsBloodGroup = bloodTypes.includes(donationType);
    if (needsBloodGroup && !bloodGroup) {
      setFormError('Blood group is required for this donation type');
      setSubmitting(false);
      return;
    }

    const { error } = await supabase.from('requests').insert({
      requester_id: user.id,
      donation_type: donationType,
      blood_group: needsBloodGroup ? bloodGroup : null,
      urgency,
      patient_name: patientName,
      description,
      location,
    });

    if (error) {
      setFormError(error.message);
      setSubmitting(false);
      return;
    }

    // Reset form
    setDonationType('Blood');
    setBloodGroup('');
    setUrgency('medium');
    setPatientName('');
    setDescription('');
    setLocation('');
    setShowForm(false);
    setSubmitting(false);
  };

  const handleAccept = async (req: Request) => {
    if (!user) return;
    await supabase
      .from('requests')
      .update({ status: 'accepted', accepted_by: user.id, accepted_at: new Date().toISOString() })
      .eq('id', req.id);

    // Notify the requester
    await supabase.from('notifications').insert({
      user_id: req.requester_id,
      type: 'status_update',
      title: 'Request Accepted',
      message: `${profile?.full_name ?? 'A donor'} accepted your ${req.donation_type} request.`,
    });
  };

  const handleComplete = async (req: Request) => {
    if (!user) return;
    await supabase
      .from('requests')
      .update({ status: 'completed', completed_at: new Date().toISOString() })
      .eq('id', req.id);

    // Record donation
    if (req.accepted_by) {
      await supabase.from('donations').insert({
        donor_id: req.accepted_by,
        request_id: req.id,
        donation_type: req.donation_type,
        blood_group: req.blood_group,
        notes: `Completed for ${req.patient_name || 'patient'}`,
        donated_at: new Date().toISOString(),
      });
    }

    // Notify requester
    await supabase.from('notifications').insert({
      user_id: req.requester_id,
      type: 'status_update',
      title: 'Request Completed',
      message: `Your ${req.donation_type} request has been completed.`,
    });
  };

  const handleCancel = async (req: Request) => {
    await supabase.from('requests').update({ status: 'cancelled' }).eq('id', req.id);
  };

  const canCreate = profile?.role === 'recipient' || profile?.role === 'hospital';
  const canAccept = profile?.role === 'donor';
  const canComplete = profile?.role === 'recipient' || profile?.role === 'hospital' || profile?.role === 'admin';

  const sortedReqs = [...requests].sort((a, b) => {
    const urgencyOrder: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
    return (urgencyOrder[a.urgency] ?? 4) - (urgencyOrder[b.urgency] ?? 4);
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Emergency Requests</h2>
          <p className="text-sm text-slate-500 mt-0.5">Real-time donation requests from recipients and hospitals</p>
        </div>
        {canCreate && (
          <button onClick={() => setShowForm(true)} className="btn-primary">
            <Plus className="w-4 h-4" />
            New Request
          </button>
        )}
      </div>

      {/* Realtime indicator */}
      <div className="flex items-center gap-2 text-xs text-slate-500">
        <span className="w-2 h-2 rounded-full bg-primary-500 animate-pulse" />
        Live updates enabled
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <span className="w-8 h-8 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
        </div>
      ) : sortedReqs.length === 0 ? (
        <div className="card p-12 text-center">
          <AlertCircle className="w-12 h-12 text-slate-200 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No emergency requests</p>
          <p className="text-sm text-slate-400 mt-1">
            {canCreate ? 'Create a new request to get started' : 'Check back later for updates'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {sortedReqs.map((r) => {
            const isOwn = r.requester_id === user?.id;
            const hasAccepted = !!r.accepted_by;
            return (
              <div key={r.id} className={`card p-5 ${r.urgency === 'critical' ? 'border-danger-200 ring-1 ring-danger-100' : ''}`}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                      r.urgency === 'critical' ? 'bg-danger-50 text-danger-600' :
                      r.urgency === 'high' ? 'bg-warning-50 text-warning-600' :
                      'bg-accent-50 text-accent-600'
                    }`}>
                      <Droplet className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-slate-900">{r.donation_type}</h3>
                        {r.blood_group && (
                          <span className="badge bg-danger-50 text-danger-700 font-bold">{r.blood_group}</span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3" />
                        {new Date(r.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <StatusBadge status={r.status} />
                    <UrgencyBadge urgency={r.urgency} />
                  </div>
                </div>

                {r.patient_name && (
                  <p className="text-sm text-slate-600 flex items-center gap-1.5 mb-1">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    {r.patient_name}
                  </p>
                )}
                {r.description && <p className="text-sm text-slate-600 mb-2">{r.description}</p>}
                {r.location && (
                  <p className="text-sm text-slate-500 flex items-center gap-1.5 mb-3">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {r.location}
                  </p>
                )}

                <div className="flex gap-2 pt-3 border-t border-slate-100">
                  {canAccept && r.status === 'pending' && (
                    <button onClick={() => handleAccept(r)} className="btn-primary flex-1">
                      <CheckCircle className="w-4 h-4" />
                      Accept Request
                    </button>
                  )}
                  {canComplete && (isOwn || hasAccepted) && r.status === 'accepted' && (
                    <button onClick={() => handleComplete(r)} className="btn-primary flex-1">
                      <CheckCircle className="w-4 h-4" />
                      Mark Completed
                    </button>
                  )}
                  {isOwn && (r.status === 'pending' || r.status === 'accepted') && (
                    <button onClick={() => handleCancel(r)} className="btn-secondary">
                      Cancel
                    </button>
                  )}
                  {r.status === 'completed' && (
                    <div className="flex items-center gap-2 text-primary-600 text-sm font-medium w-full">
                      <CheckCircle className="w-4 h-4" />
                      Request fulfilled
                    </div>
                  )}
                  {r.status === 'cancelled' && (
                    <div className="text-slate-400 text-sm font-medium w-full">Request cancelled</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create form modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 animate-fade-in" onClick={() => setShowForm(false)}>
          <div className="card p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto animate-slide-up" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-slate-900">Create Emergency Request</h3>
              <button onClick={() => setShowForm(false)} className="w-9 h-9 rounded-lg hover:bg-slate-100 flex items-center justify-center">
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 p-3 rounded-xl bg-danger-50 border border-danger-100 text-danger-700 text-sm">
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Donation Type</label>
                  <select value={donationType} onChange={(e) => setDonationType(e.target.value)} className="input">
                    {DONATION_TYPES.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                {bloodTypes.includes(donationType) && (
                  <div>
                    <label className="label">Blood Group</label>
                    <select value={bloodGroup} onChange={(e) => setBloodGroup(e.target.value)} className="input">
                      <option value="">Select group</option>
                      {BLOOD_GROUPS.map((bg) => (
                        <option key={bg} value={bg}>{bg}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              <div>
                <label className="label">Urgency Level</label>
                <div className="grid grid-cols-4 gap-2">
                  {URGENCY_LEVELS.map((u) => (
                    <button
                      key={u}
                      type="button"
                      onClick={() => setUrgency(u)}
                      className={`py-2.5 rounded-xl text-sm font-medium capitalize transition-all border-2 ${
                        urgency === u
                          ? u === 'critical' ? 'border-danger-500 bg-danger-50 text-danger-700'
                            : u === 'high' ? 'border-warning-500 bg-warning-50 text-warning-700'
                            : u === 'medium' ? 'border-accent-500 bg-accent-50 text-accent-700'
                            : 'border-slate-400 bg-slate-50 text-slate-700'
                          : 'border-slate-200 text-slate-500 hover:border-slate-300'
                      }`}
                    >
                      {u}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="label">Patient Name (optional)</label>
                <input type="text" value={patientName} onChange={(e) => setPatientName(e.target.value)} placeholder="Patient name" className="input" />
              </div>

              <div>
                <label className="label">Description</label>
                <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe the need..." rows={3} className="input resize-none" />
              </div>

              <div>
                <label className="label">Location</label>
                <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City, hospital, or address" className="input" />
              </div>

              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" disabled={submitting} className="btn-primary flex-1">
                  {submitting ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Create Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
