import { useEffect, useState } from 'react';
import { User, MapPin, Phone, Droplet, Save, Check, Building2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { supabase, Donor, Hospital, BLOOD_GROUPS, DONATION_TYPES } from '../../lib/supabase';

export default function ProfilePage() {
  const { user, profile, refreshProfile } = useAuth();
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [location, setLocation] = useState(profile?.location ?? '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Donor-specific
  const [donor, setDonor] = useState<Donor | null>(null);
  const [bloodGroup, setBloodGroup] = useState('');
  const [donationTypes, setDonationTypes] = useState<string[]>([]);
  const [isAvailable, setIsAvailable] = useState(true);

  // Hospital-specific
  const [hospital, setHospital] = useState<Hospital | null>(null);
  const [hospName, setHospName] = useState('');
  const [hospType, setHospType] = useState<'hospital' | 'blood_bank'>('hospital');
  const [hospAddress, setHospAddress] = useState('');
  const [hospCity, setHospCity] = useState('');
  const [hospPhone, setHospPhone] = useState('');

  useEffect(() => {
    if (!user) return;
    if (profile?.role === 'donor') {
      supabase.from('donors').select('*').eq('user_id', user.id).maybeSingle().then(({ data }) => {
        if (data) {
          setDonor(data as Donor);
          setBloodGroup(data.blood_group ?? '');
          setDonationTypes(data.donation_types ?? []);
          setIsAvailable(data.is_available);
        }
      });
    } else if (profile?.role === 'hospital') {
      supabase.from('hospitals').select('*').eq('profile_id', user.id).maybeSingle().then(({ data }) => {
        if (data) {
          setHospital(data as Hospital);
          setHospName(data.name);
          setHospType(data.type);
          setHospAddress(data.address);
          setHospCity(data.city);
          setHospPhone(data.phone);
        }
      });
    }
  }, [user, profile]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);

    // Update profile
    await supabase
      .from('profiles')
      .update({ full_name: fullName, phone, location })
      .eq('id', user.id);

    // Update donor info
    if (profile?.role === 'donor') {
      if (donor) {
        await supabase
          .from('donors')
          .update({ blood_group: bloodGroup || null, donation_types: donationTypes, is_available: isAvailable })
          .eq('id', donor.id);
      } else {
        await supabase
          .from('donors')
          .insert({ user_id: user.id, blood_group: bloodGroup || null, donation_types: donationTypes, is_available: isAvailable });
      }
    }

    // Update hospital info
    if (profile?.role === 'hospital') {
      if (hospital) {
        await supabase
          .from('hospitals')
          .update({ name: hospName, type: hospType, address: hospAddress, city: hospCity, phone: hospPhone })
          .eq('id', hospital.id);
      } else {
        await supabase
          .from('hospitals')
          .insert({ profile_id: user.id, name: hospName, type: hospType, address: hospAddress, city: hospCity, phone: hospPhone });
      }
    }

    await refreshProfile();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const toggleDonationType = (t: string) => {
    setDonationTypes((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl">
      <div>
        <h2 className="text-xl font-bold text-slate-900">My Profile</h2>
        <p className="text-sm text-slate-500 mt-0.5">Manage your personal information and donation preferences</p>
      </div>

      {/* Profile card */}
      <div className="card p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-2xl bg-primary-100 text-primary-700 flex items-center justify-center text-2xl font-bold">
            {fullName.charAt(0).toUpperCase() || 'U'}
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">{fullName || 'Your Name'}</h3>
            <p className="text-sm text-slate-500 capitalize">{profile?.role}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="label">Full Name</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
              <input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} className="input pl-11" />
            </div>
          </div>
          <div>
            <label className="label">Phone</label>
            <div className="relative">
              <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
              <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+1 234 567 890" className="input pl-11" />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label className="label">Location</label>
            <div className="relative">
              <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
              <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City, State" className="input pl-11" />
            </div>
          </div>
        </div>
      </div>

      {/* Donor-specific */}
      {profile?.role === 'donor' && (
        <div className="card p-6">
          <div className="flex items-center gap-2 mb-5">
            <Droplet className="w-5 h-5 text-primary-600" />
            <h3 className="font-semibold text-slate-900">Donor Information</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="label">Blood Group</label>
              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                {BLOOD_GROUPS.map((bg) => (
                  <button
                    key={bg}
                    type="button"
                    onClick={() => setBloodGroup(bg)}
                    className={`py-2.5 rounded-xl text-sm font-bold transition-all border-2 ${
                      bloodGroup === bg
                        ? 'border-danger-500 bg-danger-50 text-danger-700'
                        : 'border-slate-200 text-slate-500 hover:border-slate-300'
                    }`}
                  >
                    {bg}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="label">Donation Types</label>
              <div className="flex flex-wrap gap-2">
                {DONATION_TYPES.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => toggleDonationType(t)}
                    className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all border-2 ${
                      donationTypes.includes(t)
                        ? 'border-primary-500 bg-primary-50 text-primary-700'
                        : 'border-slate-200 text-slate-500 hover:border-slate-300'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="label">Availability Status</label>
              <button
                type="button"
                onClick={() => setIsAvailable((v) => !v)}
                className={`flex items-center gap-3 p-3 rounded-xl border-2 transition-all w-full ${
                  isAvailable ? 'border-primary-500 bg-primary-50' : 'border-slate-200'
                }`}
              >
                <div className={`w-10 h-6 rounded-full transition-colors relative ${isAvailable ? 'bg-primary-500' : 'bg-slate-300'}`}>
                  <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all ${isAvailable ? 'left-4.5' : 'left-0.5'}`} />
                </div>
                <span className={`text-sm font-medium ${isAvailable ? 'text-primary-700' : 'text-slate-500'}`}>
                  {isAvailable ? 'Available to donate' : 'Currently unavailable'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Hospital-specific */}
      {profile?.role === 'hospital' && (
        <div className="card p-6">
          <div className="flex items-center gap-2 mb-5">
            <Building2 className="w-5 h-5 text-primary-600" />
            <h3 className="font-semibold text-slate-900">Hospital / Blood Bank Information</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Facility Name</label>
              <input type="text" value={hospName} onChange={(e) => setHospName(e.target.value)} placeholder="General Hospital" className="input" />
            </div>
            <div>
              <label className="label">Type</label>
              <select value={hospType} onChange={(e) => setHospType(e.target.value as 'hospital' | 'blood_bank')} className="input">
                <option value="hospital">Hospital</option>
                <option value="blood_bank">Blood Bank</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="label">Address</label>
              <input type="text" value={hospAddress} onChange={(e) => setHospAddress(e.target.value)} placeholder="Street address" className="input" />
            </div>
            <div>
              <label className="label">City</label>
              <input type="text" value={hospCity} onChange={(e) => setHospCity(e.target.value)} placeholder="City" className="input" />
            </div>
            <div>
              <label className="label">Contact Phone</label>
              <input type="tel" value={hospPhone} onChange={(e) => setHospPhone(e.target.value)} placeholder="+1 234 567 890" className="input" />
            </div>
          </div>
        </div>
      )}

      {/* Save button */}
      <div className="flex justify-end">
        <button onClick={handleSave} disabled={saving} className="btn-primary">
          {saving ? (
            <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : saved ? (
            <>
              <Check className="w-4 h-4" />
              Saved!
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Save Changes
            </>
          )}
        </button>
      </div>
    </div>
  );
}
