/*
# LifeLink — Smart Healthcare Donation Platform Schema

## Overview
Creates the full database schema for LifeLink, a healthcare donation platform
connecting donors, recipients, hospitals, and administrators. Supports blood,
organ, tissue, plasma, platelet, bone marrow, and eye donations with real-time
emergency requests and notifications.

## 1. New Tables
### `profiles` — extends auth.users with role and personal info
### `hospitals` — hospital/blood bank directory
### `donors` — donor medical and availability info
### `requests` — emergency and scheduled donation requests
### `donations` — completed donation history records
### `notifications` — real-time user notifications

## 2. Security (RLS)
- All tables have RLS enabled.
- Profiles: readable by all authenticated, update only own.
- Hospitals: readable by all, managed by owner.
- Donors: readable by all (search), managed by owner.
- Requests: readable by all, insert by authenticated, update by participants.
- Donations: readable by donor, requester, hospital, admin.
- Notifications: read/update only by owner.

## 3. Realtime
- requests, notifications, donations tables broadcast changes.

## 4. Important Notes
- Trigger auto-creates profile row on signup using metadata.
- Indexes on frequently queried columns.
*/

-- ============ PROFILES ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'donor' CHECK (role IN ('donor','recipient','hospital','admin')),
  full_name text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  location text DEFAULT '',
  latitude double precision,
  longitude double precision,
  avatar_url text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_all" ON profiles;
CREATE POLICY "profiles_select_all" ON profiles FOR SELECT
  TO authenticated USING (true);
DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, role, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'role', 'donor'),
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============ HOSPITALS ============
CREATE TABLE IF NOT EXISTS hospitals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT '',
  type text NOT NULL DEFAULT 'hospital' CHECK (type IN ('hospital','blood_bank')),
  address text DEFAULT '',
  city text DEFAULT '',
  latitude double precision,
  longitude double precision,
  phone text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE hospitals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "hospitals_select_all" ON hospitals;
CREATE POLICY "hospitals_select_all" ON hospitals FOR SELECT
  TO authenticated USING (true);
DROP POLICY IF EXISTS "hospitals_insert_own" ON hospitals;
CREATE POLICY "hospitals_insert_own" ON hospitals FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = profile_id);
DROP POLICY IF EXISTS "hospitals_update_own" ON hospitals;
CREATE POLICY "hospitals_update_own" ON hospitals FOR UPDATE
  TO authenticated USING (auth.uid() = profile_id) WITH CHECK (auth.uid() = profile_id);
DROP POLICY IF EXISTS "hospitals_delete_own" ON hospitals;
CREATE POLICY "hospitals_delete_own" ON hospitals FOR DELETE
  TO authenticated USING (auth.uid() = profile_id);

-- ============ DONORS ============
CREATE TABLE IF NOT EXISTS donors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  blood_group text CHECK (blood_group IN ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
  donation_types text[] NOT NULL DEFAULT '{}',
  is_available boolean NOT NULL DEFAULT true,
  last_donation_date date,
  medical_notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE donors ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "donors_select_all" ON donors;
CREATE POLICY "donors_select_all" ON donors FOR SELECT
  TO authenticated USING (true);
DROP POLICY IF EXISTS "donors_insert_own" ON donors;
CREATE POLICY "donors_insert_own" ON donors FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "donors_update_own" ON donors;
CREATE POLICY "donors_update_own" ON donors FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "donors_delete_own" ON donors;
CREATE POLICY "donors_delete_own" ON donors FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ REQUESTS ============
CREATE TABLE IF NOT EXISTS requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  hospital_id uuid REFERENCES hospitals(id) ON DELETE SET NULL,
  donation_type text NOT NULL,
  blood_group text,
  urgency text NOT NULL DEFAULT 'medium' CHECK (urgency IN ('low','medium','high','critical')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','completed','cancelled')),
  patient_name text DEFAULT '',
  description text DEFAULT '',
  location text DEFAULT '',
  latitude double precision,
  longitude double precision,
  accepted_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  accepted_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "requests_select_all" ON requests;
CREATE POLICY "requests_select_all" ON requests FOR SELECT
  TO authenticated USING (true);
DROP POLICY IF EXISTS "requests_insert_own" ON requests;
CREATE POLICY "requests_insert_own" ON requests FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = requester_id);
DROP POLICY IF EXISTS "requests_update_participants" ON requests;
CREATE POLICY "requests_update_participants" ON requests FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = requester_id OR
    auth.uid() = accepted_by OR
    EXISTS (SELECT 1 FROM hospitals WHERE hospitals.id = requests.hospital_id AND hospitals.profile_id = auth.uid()) OR
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  )
  WITH CHECK (
    auth.uid() = requester_id OR
    auth.uid() = accepted_by OR
    EXISTS (SELECT 1 FROM hospitals WHERE hospitals.id = requests.hospital_id AND hospitals.profile_id = auth.uid()) OR
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );
DROP POLICY IF EXISTS "requests_delete_own" ON requests;
CREATE POLICY "requests_delete_own" ON requests FOR DELETE
  TO authenticated USING (auth.uid() = requester_id);

-- ============ DONATIONS ============
CREATE TABLE IF NOT EXISTS donations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  donor_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  request_id uuid REFERENCES requests(id) ON DELETE SET NULL,
  hospital_id uuid REFERENCES hospitals(id) ON DELETE SET NULL,
  donation_type text NOT NULL,
  blood_group text,
  quantity text DEFAULT '',
  notes text DEFAULT '',
  donated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE donations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "donations_select_related" ON donations;
CREATE POLICY "donations_select_related" ON donations FOR SELECT
  TO authenticated
  USING (
    auth.uid() = donor_id OR
    EXISTS (SELECT 1 FROM hospitals WHERE hospitals.id = donations.hospital_id AND hospitals.profile_id = auth.uid()) OR
    EXISTS (SELECT 1 FROM requests WHERE requests.id = donations.request_id AND requests.requester_id = auth.uid()) OR
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );
DROP POLICY IF EXISTS "donations_insert_auth" ON donations;
CREATE POLICY "donations_insert_auth" ON donations FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = donor_id OR
    EXISTS (SELECT 1 FROM hospitals WHERE hospitals.id = donations.hospital_id AND hospitals.profile_id = auth.uid()) OR
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );
DROP POLICY IF EXISTS "donations_update_admin" ON donations;
CREATE POLICY "donations_update_admin" ON donations FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============ NOTIFICATIONS ============
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('new_request','match_found','status_update','message')),
  title text NOT NULL DEFAULT '',
  message text NOT NULL DEFAULT '',
  link text,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "notifications_select_own" ON notifications;
CREATE POLICY "notifications_select_own" ON notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "notifications_insert_own" ON notifications;
CREATE POLICY "notifications_insert_own" ON notifications FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "notifications_update_own" ON notifications;
CREATE POLICY "notifications_update_own" ON notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "notifications_delete_own" ON notifications;
CREATE POLICY "notifications_delete_own" ON notifications FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ INDEXES ============
CREATE INDEX IF NOT EXISTS idx_donors_blood_group ON donors(blood_group);
CREATE INDEX IF NOT EXISTS idx_donors_user_id ON donors(user_id);
CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status);
CREATE INDEX IF NOT EXISTS idx_requests_urgency ON requests(urgency);
CREATE INDEX IF NOT EXISTS idx_requests_requester_id ON requests(requester_id);
CREATE INDEX IF NOT EXISTS idx_donations_donor_id ON donations(donor_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_hospitals_profile_id ON hospitals(profile_id);
