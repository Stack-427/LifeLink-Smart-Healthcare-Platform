/*
# Enable Realtime on LifeLink tables

Adds requests, notifications, and donations tables to the supabase_realtime
publication so the frontend can subscribe to row-level changes via Supabase
channels for live emergency tracking and instant alerts.
*/

ALTER PUBLICATION supabase_realtime ADD TABLE requests;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE donations;
